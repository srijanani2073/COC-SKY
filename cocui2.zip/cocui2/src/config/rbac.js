export const RBAC = {
  Dashboard: ["Admin", "Investigator", "Analyst", "Viewer"],
  Cases: ["Admin", "Investigator", "Viewer"],
  Evidence: ["Admin", "Investigator", "Analyst", "Viewer"],
  Timeline: ["Admin", "Investigator", "Analyst", "Viewer"],
  Reports: ["Admin", "Investigator", "Viewer"],
  Alerts: ["Admin"],
  Custody: ["Admin", "Investigator", "Analyst"]
};
